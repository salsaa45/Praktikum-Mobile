import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold
      (
        appBar: AppBar
        (
          title: Text
          (
          "Dashboard",
          style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          backgroundColor: const Color.fromARGB(255, 2, 115, 207),
        ),
        body: ListView
        (
          padding: const EdgeInsets.all(16.0),
          children: 
          [
            CircleAvatar
            (
              radius: 60.0,
              backgroundImage:
              AssetImage('lib/assets/images/penguin.jpg'),
            ),
            SizedBox(height: 10),
                  
            Text
            (
              "Ghefira Nur Salsabila",
              style:
              TextStyle
              (
                fontSize: 20.0, 
                fontWeight: FontWeight.bold
              ),
                textAlign: TextAlign.center,
            ),
            Text
            (
              "123220178",
              style: TextStyle(fontSize: 16.0),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
                  
            Row
            (
              mainAxisAlignment: MainAxisAlignment.center,
              children: 
              [
                ElevatedButton
                  (
                    onPressed: () {},
                    child: Text("Tombol 1"),
                  ),
                SizedBox(width: 10),
                      
                ElevatedButton
                  (
                    onPressed: () {},
                    child: Text("Tombol 2"),
                  ),
                SizedBox(width: 10),
                      
                ElevatedButton
                  (
                    onPressed: () {},
                    child: Text("Tombol 3"),
                  ),
                SizedBox(width: 10),
              ],
            ),
            SizedBox(height: 20),
                  
            SizedBox
            (
              height: 500,
              child: GridView.count
              (
                padding: const EdgeInsets.all(10),
                shrinkWrap: true,
                childAspectRatio: 1.3,
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: 
                [
                  _buildCard(Colors.blue),
                  _buildCard(Colors.green),
                  _buildCard(Colors.red),
                  _buildCard(Colors.orange),
                ],
              ),      
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(Color color) 
  {
    return Card
    (
      color: color,
      shape: RoundedRectangleBorder
      (
        borderRadius: BorderRadius.circular(16)
      ),
      child: const Center
      (
        child: FlutterLogo(size: 40),
      ),
    );
  }
}