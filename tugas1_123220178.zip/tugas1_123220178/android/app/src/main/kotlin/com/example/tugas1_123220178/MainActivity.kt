package com.example.tugas1_123220178

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
